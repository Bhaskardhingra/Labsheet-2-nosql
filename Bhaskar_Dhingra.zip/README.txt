BHASKAR DHINGRA — NOSQL DATABASE DESIGN LAB SHEET 3

Contents:
- Bhaskar_Dhingra_NoSQL_Lab_Solutions.md: complete solutions for questions 1–15, with sample MongoDB documents and queries.

How to use:
1. Open the Markdown file in a text editor or Markdown viewer.
2. Copy and run each question's code block in mongosh, one section at a time.
3. Question 11 uses MongoDB transactions and requires a replica set or sharded cluster.

These are sample implementations; update sample names and data as needed for your lab submission.
