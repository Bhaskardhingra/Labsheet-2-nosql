# NOSQL DATABASE DESIGN – LAB SHEET 3
**Submitted by: Bhaskar Dhingra**

These are MongoDB (`mongosh`) sample solutions for all 15 questions. Run each section in `mongosh`. The examples use sample data, so you can insert more documents to test additional cases.

---

## 1. Student Activity Tracking System

```javascript
use StudentActivityDB

db.students.insertMany([
  {
    studentId: 101, name: "Aarav", age: 20,
    courses: ["BCA", "DBMS"], attendance: 88,
    skills: ["Python", "MongoDB"],
    recentActivities: [
      { activity: "Quiz", score: 85, date: ISODate("2026-10-01") },
      { activity: "Assignment", score: 92, date: ISODate("2026-10-05") }
    ]
  },
  {
    studentId: 102, name: "Riya", age: 21,
    courses: ["BCA", "Java"], attendance: 67,
    skills: ["Java"],
    recentActivities: [{ activity: "Quiz", score: 55, date: ISODate("2026-10-03") }]
  }
])

// Students with attendance of at least 75%
db.students.find({ attendance: { $gte: 75 } })

// Students enrolled in BCA
db.students.find({ courses: "BCA" })

// Students who know MongoDB
db.students.find({ skills: "MongoDB" })

// Students with a recent activity score of 80 or more
db.students.find({ recentActivities: { $elemMatch: { score: { $gte: 80 } } } })

// Students who completed an Assignment activity
db.students.find({ recentActivities: { $elemMatch: { activity: "Assignment" } } })
```

## 2. Event Logging System

```javascript
use EventLoggingDB

db.events.insertMany([
  { user: "user1", eventType: "failed-login", timestamp: ISODate("2026-10-10T09:00:00Z") },
  { user: "user1", eventType: "failed-login", timestamp: ISODate("2026-10-10T09:01:00Z") },
  { user: "user1", eventType: "login", timestamp: ISODate("2026-10-10T09:02:00Z") },
  { user: "user2", eventType: "file-upload", timestamp: ISODate("2026-10-10T10:00:00Z") },
  { user: "user2", eventType: "logout", timestamp: ISODate("2026-10-10T10:30:00Z") },
  { user: "user2", eventType: "password-change", timestamp: ISODate("2026-10-10T11:00:00Z") }
])

// Repeated failed login attempts by user
db.events.aggregate([
  { $match: { eventType: "failed-login" } },
  { $group: { _id: "$user", failedAttempts: { $sum: 1 } } },
  { $match: { failedAttempts: { $gte: 2 } } }
])

// Most frequent event types
db.events.aggregate([
  { $group: { _id: "$eventType", count: { $sum: 1 } } },
  { $sort: { count: -1 } }
])

// Find events for a particular user, newest first
db.events.find({ user: "user1" }).sort({ timestamp: -1 })
```

## 3. Mini Blogging Platform

```javascript
use MiniBlogDB

db.blogs.insertMany([
  {
    title: "Learning MongoDB", author: "Bhaskar", category: "Technology",
    tags: ["mongodb", "database"], published: true,
    publishedAt: ISODate("2026-09-20"),
    comments: [{ user: "Aarav", text: "Helpful article" }]
  },
  {
    title: "Healthy Habits", author: "Riya", category: "Lifestyle",
    tags: ["health", "habits"], published: true,
    publishedAt: ISODate("2026-09-22"), comments: []
  }
])

// Blogs in Technology category
db.blogs.find({ category: "Technology" })

// Blogs containing the mongodb tag
db.blogs.find({ tags: "mongodb" })

// Blogs tagged with both mongodb and database
db.blogs.find({ tags: { $all: ["mongodb", "database"] } })

// Technology blogs with either mongodb or database tag
db.blogs.find({ category: "Technology", tags: { $in: ["mongodb", "database"] } })

// Show blog titles and comments
db.blogs.find({}, { title: 1, comments: 1, _id: 0 })
```

## 4. Flexible Product Catalog

```javascript
use ProductCatalogDB

db.products.insertMany([
  { name: "Laptop A", category: "laptop", brand: "Lenovo", ramGB: 16, storageGB: 512, processor: "i5" },
  { name: "Mobile A", category: "mobile", brand: "Samsung", ramGB: 8, storageGB: 256, batteryMah: 5000 },
  { name: "Camera A", category: "camera", brand: "Canon", megapixels: 24, lensMount: "RF" }
])

// Laptops with at least 16 GB RAM
db.products.find({ category: "laptop", ramGB: { $gte: 16 } })

// Mobiles with battery capacity of 5000 mAh or more
db.products.find({ category: "mobile", batteryMah: { $gte: 5000 } })

// Cameras with 24 or more megapixels
db.products.find({ category: "camera", megapixels: { $gte: 24 } })

// Products of a particular brand
db.products.find({ brand: "Samsung" })
```

## 5. E-Commerce Order Management System

```javascript
use EcommerceDB

db.customers.insertMany([
  { customerId: 1, name: "Aarav", email: "aarav@example.com" },
  { customerId: 2, name: "Riya", email: "riya@example.com" }
])

db.products.insertMany([
  { productId: 11, name: "Keyboard", price: 800 },
  { productId: 12, name: "Mouse", price: 400 }
])

db.orders.insertMany([
  {
    orderId: 501, customerId: 1, orderDate: ISODate("2026-10-01"),
    items: [{ productId: 11, name: "Keyboard", quantity: 1, price: 800 },
            { productId: 12, name: "Mouse", quantity: 2, price: 400 }]
  },
  {
    orderId: 502, customerId: 1, orderDate: ISODate("2026-10-08"),
    items: [{ productId: 12, name: "Mouse", quantity: 1, price: 400 }]
  }
])

// Complete purchase history of customer 1
db.orders.find({ customerId: 1 }).sort({ orderDate: -1 })

// Calculate each order total
db.orders.aggregate([
  { $unwind: "$items" },
  { $group: {
      _id: "$orderId",
      customerId: { $first: "$customerId" },
      orderDate: { $first: "$orderDate" },
      total: { $sum: { $multiply: ["$items.quantity", "$items.price"] } }
  }},
  { $sort: { orderDate: -1 } }
])

// Look up customer information with each order
db.orders.aggregate([
  { $match: { customerId: 1 } },
  { $lookup: { from: "customers", localField: "customerId", foreignField: "customerId", as: "customer" } }
])
```

## 6. Website Analytics System

```javascript
use WebsiteAnalyticsDB

db.visits.insertMany([
  { page: "/home", userId: 1, device: "mobile", browser: "Safari", location: "India", timestamp: ISODate("2026-10-10T08:00:00Z") },
  { page: "/home", userId: 2, device: "desktop", browser: "Chrome", location: "India", timestamp: ISODate("2026-10-10T08:05:00Z") },
  { page: "/products", userId: 1, device: "mobile", browser: "Safari", location: "India", timestamp: ISODate("2026-10-10T08:10:00Z") },
  { page: "/home", userId: 3, device: "tablet", browser: "Chrome", location: "India", timestamp: ISODate("2026-10-10T08:15:00Z") }
])

// Most visited pages
db.visits.aggregate([
  { $group: { _id: "$page", visits: { $sum: 1 } } },
  { $sort: { visits: -1 } }
])

// Commonly used devices
db.visits.aggregate([
  { $group: { _id: "$device", uses: { $sum: 1 } } },
  { $sort: { uses: -1 } }
])

// Visits within a date range
db.visits.find({
  timestamp: { $gte: ISODate("2026-10-10T00:00:00Z"), $lt: ISODate("2026-10-11T00:00:00Z") }
})
```

## 7. Content Management System

```javascript
use ContentManagementDB

db.articles.insertMany([
  { title: "MongoDB Basics", author: "Bhaskar", category: "Education", tags: ["database"], status: "published", publishedAt: ISODate("2026-09-20") },
  { title: "Draft: Indexes", author: "Bhaskar", category: "Technology", tags: ["mongodb"], status: "draft" },
  { title: "Web Design", author: "Riya", category: "Technology", tags: ["web"], status: "published", publishedAt: ISODate("2026-09-25") }
])

// Published articles
db.articles.find({ status: "published" })

// Unpublished/draft articles
db.articles.find({ status: { $ne: "published" } })

// Published Technology articles
db.articles.find({ status: "published", category: "Technology" })

// Articles by author, newest first
db.articles.find({ author: "Bhaskar" }).sort({ publishedAt: -1 })
```

## 8. Shopping Cart Using Embedded Documents

```javascript
use ShoppingCartDB

db.carts.insertOne({
  userId: 101,
  items: [
    { productId: 1, name: "T-shirt", price: 500, quantity: 2 },
    { productId: 2, name: "Cap", price: 250, quantity: 1 }
  ]
})

// Add a new product to the cart
db.carts.updateOne(
  { userId: 101 },
  { $push: { items: { productId: 3, name: "Bottle", price: 300, quantity: 1 } } }
)

// Change quantity of product 1
db.carts.updateOne(
  { userId: 101, "items.productId": 1 },
  { $set: { "items.$.quantity": 3 } }
)

// Remove product 2
db.carts.updateOne(
  { userId: 101 },
  { $pull: { items: { productId: 2 } } }
)

// Calculate current cart value
db.carts.aggregate([
  { $match: { userId: 101 } },
  { $unwind: "$items" },
  { $group: { _id: "$userId", cartTotal: { $sum: { $multiply: ["$items.price", "$items.quantity"] } } } }
])
```

## 9. Product Review and Rating System

```javascript
use ProductReviewsDB

db.reviews.insertMany([
  { productId: 1, customer: "Aarav", rating: 5, review: "Excellent" },
  { productId: 1, customer: "Riya", rating: 4, review: "Good" },
  { productId: 2, customer: "Aarav", rating: 3, review: "Average" },
  { productId: 2, customer: "Kabir", rating: 4, review: "Nice" }
])

// Average rating and review count for each product
db.reviews.aggregate([
  { $group: {
      _id: "$productId",
      averageRating: { $avg: "$rating" },
      numberOfReviews: { $sum: 1 }
  }},
  { $sort: { averageRating: -1 } }
])

// Reviews for one product
db.reviews.find({ productId: 1 })
```

## 10. Inventory Monitoring System

```javascript
use InventoryDB

db.inventory.insertMany([
  { productId: 1, name: "Notebook", stock: 5, minStock: 10, supplier: "ABC Supplies", restockDate: ISODate("2026-10-15") },
  { productId: 2, name: "Pen", stock: 100, minStock: 20, supplier: "XYZ Traders", restockDate: ISODate("2026-10-20") },
  { productId: 3, name: "Folder", stock: 8, minStock: 8, supplier: "ABC Supplies", restockDate: ISODate("2026-10-16") }
])

// Products at or below minimum stock
db.inventory.find({ $expr: { $lte: ["$stock", "$minStock"] } })

// Urgent restocking list, lowest stock first
db.inventory.find({ $expr: { $lte: ["$stock", "$minStock"] } }).sort({ stock: 1 })
```

## 11. Bank Wallet Transfer Using MongoDB Transactions

**Requirement:** transactions require a MongoDB deployment that supports transactions, such as a replica set or sharded cluster. A standalone local MongoDB server may not support this.

```javascript
use WalletDB

db.wallets.insertMany([
  { userId: 1, name: "Aarav", balance: 5000 },
  { userId: 2, name: "Riya", balance: 2000 }
])

// Run this in mongosh connected to a replica set/sharded cluster.
// Transfer 1000 from user 1 to user 2 atomically.
const session = db.getMongo().startSession();
const walletDB = session.getDatabase("WalletDB");

try {
  session.startTransaction();

  const debit = walletDB.wallets.updateOne(
    { userId: 1, balance: { $gte: 1000 } },
    { $inc: { balance: -1000 } }
  );

  if (debit.modifiedCount !== 1) {
    throw new Error("Sender not found or insufficient balance");
  }

  const credit = walletDB.wallets.updateOne(
    { userId: 2 },
    { $inc: { balance: 1000 } }
  );

  if (credit.modifiedCount !== 1) {
    throw new Error("Recipient not found");
  }

  session.commitTransaction();
  print("Transfer completed successfully.");
} catch (error) {
  session.abortTransaction();
  print("Transfer failed: " + error.message);
} finally {
  session.endSession();
}

// Verify balances
db.wallets.find()
```

## 12. User Notification System

```javascript
use NotificationDB

db.notifications.insertMany([
  { userId: 1, type: "message", text: "New message received", read: false, createdAt: new Date() },
  { userId: 1, type: "order-update", text: "Order shipped", read: false, createdAt: new Date() },
  { userId: 2, type: "system-alert", text: "System maintenance tonight", read: true, createdAt: new Date() }
])

// Retrieve unread notifications for user 1
db.notifications.find({ userId: 1, read: false }).sort({ createdAt: -1 })

// Mark one notification as read
db.notifications.updateOne(
  { userId: 1, type: "message", read: false },
  { $set: { read: true, readAt: new Date() } }
)

// Mark all notifications as read for user 1
db.notifications.updateMany(
  { userId: 1, read: false },
  { $set: { read: true, readAt: new Date() } }
)
```

## 13. Course Learning Platform

```javascript
use CourseLearningDB

db.learningProgress.insertMany([
  { course: "MongoDB", instructor: "Dr. Sharma", studentId: 101, studentName: "Aarav", modules: 10, completedModules: 8, progressPercent: 80, completed: false },
  { course: "Python", instructor: "Dr. Verma", studentId: 102, studentName: "Riya", modules: 8, completedModules: 8, progressPercent: 100, completed: true },
  { course: "MongoDB", instructor: "Dr. Sharma", studentId: 103, studentName: "Kabir", modules: 10, completedModules: 4, progressPercent: 40, completed: false }
])

// Students with at least 75% progress
db.learningProgress.find({ progressPercent: { $gte: 75 } })

// Students who completed the course
db.learningProgress.find({ completed: true })

// Progress for a particular course, highest first
db.learningProgress.find({ course: "MongoDB" }).sort({ progressPercent: -1 })

// Calculate progress percentage from module counts
db.learningProgress.aggregate([
  { $project: {
      studentName: 1, course: 1, completedModules: 1, modules: 1,
      calculatedProgress: {
        $multiply: [{ $divide: ["$completedModules", "$modules"] }, 100]
      }
  }}
])
```

## 14. Real-Time Order Tracking System

```javascript
use OrderTrackingDB

db.orders.insertOne({
  orderId: "ORD1001",
  customerId: 101,
  currentStatus: "Shipped",
  statusHistory: [
    { status: "Placed", date: ISODate("2026-10-10T08:00:00Z") },
    { status: "Confirmed", date: ISODate("2026-10-10T08:15:00Z") },
    { status: "Shipped", date: ISODate("2026-10-11T09:30:00Z") }
  ]
})

// Retrieve current status
db.orders.find({ orderId: "ORD1001" }, { orderId: 1, currentStatus: 1, _id: 0 })

// Append a new status-history entry and update current status
db.orders.updateOne(
  { orderId: "ORD1001" },
  {
    $set: { currentStatus: "Delivered" },
    $push: { statusHistory: { status: "Delivered", date: new Date() } }
  }
)

// Retrieve the complete history
db.orders.find({ orderId: "ORD1001" }, { statusHistory: 1, _id: 0 })
```

## 15. Flexible News Database

```javascript
use FlexibleNewsDB

db.news.insertMany([
  {
    title: "City Opens New Library", author: "A. Singh",
    location: "Haridwar", category: "Local", tags: ["library", "education"],
    images: ["library.jpg"], source: "Daily News",
    publishedAt: ISODate("2026-10-01")
  },
  {
    title: "New Technology Update", category: "Technology",
    tags: ["technology", "AI"], source: "Tech Wire",
    publishedAt: ISODate("2026-10-02")
  },
  {
    title: "Regional Sports Event", author: "R. Mehta",
    location: "Dehradun", category: "Sports",
    tags: ["sports", "event"], publishedAt: ISODate("2026-10-03")
  }
])

// Search by category even when other fields differ
db.news.find({ category: "Technology" })

// Search articles tagged with AI
db.news.find({ tags: "AI" })

// Search articles with location field
db.news.find({ location: { $exists: true } })

// Search articles that contain an author field
db.news.find({ author: { $exists: true } })

// Search across title, category, and source
db.news.find({
  $or: [
    { title: /technology/i },
    { category: /technology/i },
    { source: /technology/i }
  ]
})

// Show available fields across documents
db.news.aggregate([
  { $project: { fields: { $objectToArray: "$$ROOT" } } },
  { $unwind: "$fields" },
  { $group: { _id: "$fields.k", occurrences: { $sum: 1 } } },
  { $sort: { _id: 1 } }
])
```

---

## How to run

1. Install MongoDB Community Server and MongoDB Shell (`mongosh`), or use MongoDB Atlas.
2. Open `mongosh` and run one question's code block at a time.
3. Each section starts with `use DatabaseName`. Sample documents are included so the queries return results.
4. Question 11 needs a replica set or sharded deployment for transaction support.
